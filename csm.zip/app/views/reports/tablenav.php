
<div class="row">
<?php if ((!empty($data['report']) && $data['report'] != null && $data['report'] != false && count($data['report']) != 0)) 
		  : ?>
	<div class="inside">
		<table id = '<?= $data['tableID']; ?>' class = "table cell-border hover <?= $data['class']; ?>">
<?php endif ?>
	