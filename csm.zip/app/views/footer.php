</div>
<div id="test">
<?php include $data['menu'].".php"; ?>
</div>
<!--/Test -->

<!-- Beggining of script declaration -->
<script type="text/javascript" src="/csm/public/js/jquery-1.11.3.min.js"></script> 
<script type="text/javascript" src="/csm/public/bootstrap/js/bootstrap.js"></script> 
<script type="text/javascript" src="/csm/public/bootstrap/js/bootstrap.min.js"></script>
<script src="/csm/public/js/BootSideMenu.js"></script>
<script type="text/javascript" src="/csm/public/js/script.js"></script>
<script type="text/javascript" src="/csm/public/js/dataTables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/csm/public/js/dataTables.js"></script>


<!-- End of script declaration -->
</body>
</html>